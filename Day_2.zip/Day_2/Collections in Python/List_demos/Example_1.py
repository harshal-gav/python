mylist = [10,20,30,40]
print(mylist)
print(type(mylist))
print(mylist[0])
print(len(mylist))
mylist.append(50)   # list is dynamic
print(mylist)
mylist[0]=12        # list is mutable
print(mylist)