# remove element from the list

mylist = [10,"hello",4.5,False]

print(mylist)
mylist.remove(4.5)
print(mylist)

