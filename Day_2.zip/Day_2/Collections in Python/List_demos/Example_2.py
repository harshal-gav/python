# list of multiple data types

mylist = [10,"hello",'A',3.4,True]
print(mylist)
print(type(mylist))
print(mylist[0])
print(len(mylist))
mylist.append(50)   # list is dynamic
print(mylist)
mylist[0]=12        # list is mutable
print(mylist)