# split a string based on space as a delimeter and convert it into list

mystring = "Learning Python is very simple"

print(mystring)

myvar = mystring.split(' ')

print(myvar)
print(type(myvar))
