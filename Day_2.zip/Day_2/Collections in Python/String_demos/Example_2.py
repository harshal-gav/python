# how to accept a string from user
mystring = input("Enter your name")
print(mystring)
print(type(mystring))
print(len(mystring))
# mystring[0]='G'  # Not possible, strings are immutable
