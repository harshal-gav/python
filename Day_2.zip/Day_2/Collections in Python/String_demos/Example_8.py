# Built-in String Methods

def fun():
	first="hello world"
	print(first)
	print(first.capitalize())  # Capitalizes first letter of string
	print(first)
fun()
