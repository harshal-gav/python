# first example of set

myset = {10,20,30,40,30}     # duplicates are not allowed
print(myset)
print(type(myset))

# iterating set
for i in myset:
    print(i)