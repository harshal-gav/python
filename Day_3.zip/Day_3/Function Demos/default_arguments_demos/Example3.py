# Error :  SyntaxError: non-default argument follows default argument

def disp(var1=10,var2):
	print(var1,"\t",var2)

def fun():

fun()
