
def disp(var):
    print("inside disp\t",var)

def myfun():
    print("inside main")
    disp(20)
myfun()



