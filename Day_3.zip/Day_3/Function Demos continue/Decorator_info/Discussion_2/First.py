def div(a,b):
    print(a/b)

div(8,4)