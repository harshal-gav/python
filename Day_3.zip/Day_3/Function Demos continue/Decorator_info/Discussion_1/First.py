# let's write some functions which do some imp. task

def fun1():
    print("Important task1")

def fun2():
    print("Important task2")

def fun3():
    print("Important task3")

def fun4():
    print("Important task4") 

fun1()
fun2()
fun3()
fun4()
