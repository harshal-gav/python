# initialize one-d array with zero

import numpy as np
first=np.zeros((1,4))                             # one row , 4 columns

print(first)
print("\n")

# initialize two-d array with zeros

second=np.zeros((3,4))                            # 3 rows and 4 columns

print(second)