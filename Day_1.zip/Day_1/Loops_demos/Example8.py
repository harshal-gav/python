

	# use a for loop over a collection
	Months = ["Jan","Feb","Mar","April","May","June"]
	for m in Months:
		print(m)

