

   for i in range(1 , 10):
       if(i==6):
       	continue
       print(i)
