

   for i in range(1,3):
       for j in range(1,3):
           print(str(i)+"\t"+str(j))

