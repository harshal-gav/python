# ternary operator in python

# syntax
[on_true] if [expression] else [on_false] 


   i=1
   print("positive") if(i>0) else print("negative")
