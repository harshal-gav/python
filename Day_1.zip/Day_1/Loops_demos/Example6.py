

   i=0
   if(i>0):
       print("positive")
   elif(i<0):
       print("negative")
   else:
        print("zero")
