# how to write infinite loop

	while True:
		i=(int)(input("Enter number\n"))
		if(i==0):
			break
		print(i)

