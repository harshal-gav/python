# Enumerate function is used for the numbering or indexing the members in the list.




	#use a for loop over a collection
	Months = ["Jan","Feb","Mar","April","May","June"]
	for i, m in enumerate (Months):
		 print(i,m)


