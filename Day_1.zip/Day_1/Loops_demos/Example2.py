

    i=1
    while(1):
        if(i==6):
            break
        print(i)
        i+=1

