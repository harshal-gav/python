# As python doesn't use curly braces for defining the scope, it is mandatory that we must follow indentation
print("hello")         
print("welcome")    
if(10>5):
    print("10 is greater than5")        #Indentation is must here
    print("10 is even number")
    print("10 is a first two digit number")
else:
    print("10 is not greater than 5")
    print("5 is an odd number")