# As python doesn't use curly braces for defining the scope, it is mandatory that we must follow indentation
    print("hello")  #    IndentationError: unexpected indent
    print("welcome")      