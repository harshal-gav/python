var=5
print(var/0)
print("done")
