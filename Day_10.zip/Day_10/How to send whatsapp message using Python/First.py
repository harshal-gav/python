import pywhatkit

# here 7,52 is time on which you want whatsapp message to go to the receiver

pywhatkit.sendwhatmsg('+919270682272','Good Morning boss',7,52)