from pandas import *

myseries=Series([10,20,30,40,50,60])
print(myseries)
print("\n")
print(myseries.sum())
print("\n")
print(myseries.add(3))
print("\n")
print(myseries.subtract(5))
print("\n")
print(myseries.divide(2))
print("\n")
print(myseries.mul(4))

