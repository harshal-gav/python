from MyPackage import One,Two      # to access "One.py" and "Two.py" modules

One.disp1()
Two.disp2()
