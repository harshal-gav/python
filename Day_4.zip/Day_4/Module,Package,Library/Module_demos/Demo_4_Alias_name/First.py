
def fun1():
    return "welcome to fun1"

def fun2():
    return "welcome to fun2"