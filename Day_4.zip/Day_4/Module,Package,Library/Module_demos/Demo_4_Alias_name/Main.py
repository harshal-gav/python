import First as F


   print(F.fun1())
   print(F.fun2())

   
