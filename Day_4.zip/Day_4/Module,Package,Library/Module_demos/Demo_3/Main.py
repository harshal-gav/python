from First import *
from Second import *


disp1(100)
disp2(300)
print(fun2())
