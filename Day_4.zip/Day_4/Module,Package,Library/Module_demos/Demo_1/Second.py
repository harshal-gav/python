def fun2():
    return "welcome to fun2"
